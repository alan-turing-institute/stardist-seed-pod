from .model import stardist-seed-pod
